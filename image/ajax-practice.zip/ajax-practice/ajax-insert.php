<?php
include('connection.php');
$name=$_POST['first_name'];
$email=$_POST['email'];
$sql="INSERT INTO registration (name,email) VALUES ('$name','$email')";
$result=$conn->query($sql);
if($result){
    echo 1;
}else{
    echo 0;
}
?>
