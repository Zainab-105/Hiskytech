<?php
include('connection.php');

$sql = "SELECT * FROM registration";
$result = $conn->query($sql);
$output = "";

if (mysqli_num_rows($result) > 0) {
    while ($row = mysqli_fetch_assoc($result)) {
     echo '<tr>
          <th scope="row">' . $row["id"] . '</th>
          <td>' . $row["name"] . '</td>
          <td>' . $row["email"] . '</td>
          <td><button class="btn-delete btn btn-danger" data-id="' . $row["id"] . '">Delete</button>
          <button class="btn-edit btn btn-success" data-eid="' . $row["id"] . '">Edit</button></td>
         
        </tr>';
    }
   
} else {
    echo '<tr><td colspan="3" style="text-align:center;">No Record Found</td></tr>';
}
?>
