<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PHP With Ajax</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css"
        integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <!-- <link rel="stylesheet" href="style.css"> -->
    <link rel="stylesheet" href="style.css">
</head>

<body>
    <h2 class="text-center">Data Insertion Using Ajax</h2>
    <div class="button">
        <div class="row">
            <div class="col-md-12">
         <form id="form-data">
         First name: <input type="text" class="form-control" id="name">
            Email: <input type="text" class="form-control" id="email"><br>
            <input type="submit" value="save" class="btn btn-primary" id="save-btn">
         </form>
     
 
            </div>
       </div>
        
    </div>
    <div>
        <table class="table table-dark" id="table-data">
            <thead>
                <tr>
                    <th scope="col">#</th>
                    <th scope="col">Name</th>
                    <th scope="col">Email</th>
                    <th scope="col">Action</th>
                </tr>
            </thead>
            <tbody>
                <!-- Data will be inserted here -->
            </tbody>
        </table>
    </div>
    <div class="success-message"></div>
    <div class="error-message"></div>
   
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js"
        integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q"
        crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js"
        integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl"
        crossorigin="anonymous"></script>
    <script>
        $(document).ready(function () {
            function loaddata() {
                $.ajax({
                    url: 'ajax-loader.php',
                    type: 'post',
                    success: function (data) {
                        $('#table-data tbody').html(data);
                    }
                });
            }

            loaddata();

            $('#save-btn').on("click", function (e) {
                e.preventDefault();
                var name = $('#name').val();
                var email = $('#email').val();
               
                    $.ajax({
                        url: "ajax-insert.php",
                        type: "post",
                        data: { first_name: name, email: email },
                        success: function (data) {
                            if (data == 1) {
                                $('#form-data').trigger('reset');
                                loaddata();
                            } else {
                               alert("Error Occured while inserting data");
                            }
                        }
                    });
                
            });

            $(document).on("click", '.btn-delete', function () {

                if (confirm("Do you really want to delete this record?")) {
                    var id = $(this).data("id");
                    var element = this;
                    $.ajax({
                        url: "ajax-delete.php",
                        type: "POST",
                        data: { id: id },
                        success: function (data) {
                            if (data == 1) {
                                loaddata();
                                $(element).closest('tr').fadeOut();
                            } else {
                                alert("Error Occured while inserting data");
                            }
                        }
                    });
                }
            });
           
             
        });
    </script>
</body>

</html>